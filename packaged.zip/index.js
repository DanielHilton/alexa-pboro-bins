'use strict';

const MyAlexaSkill = require('./src/index');

exports.handler = MyAlexaSkill.handler;